﻿ShopsN多商户商城系统基于php及vue开发。

我们的安装测试文档请参阅 doc.shopsn.cn

安装视频文档，请在百度云盘内找到视频栏目的多商户安装视频下载观看。
链接：https://pan.baidu.com/s/1YdVZ4XuGTxLxKcZee686jg
提取码：k40k




为避免不兼容产生的问题，系统强烈建议使用centos 7.x 宝塔面板 apache  php7.2  mysql5.7

未授权用户请自行调试及测试研究。

授权用户我们有专门的vip群提供技术服务及技术反馈。
