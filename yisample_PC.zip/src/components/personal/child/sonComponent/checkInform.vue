<template>
  <div>
    <com-header></com-header>
  </div>
</template>

<script>
import ComHeader from './comHeader';
  export default {
    data(){
      return{

      }
    },
    components:{
        ComHeader
    }
  }
</script>

<style lang="less" scoped>

</style>