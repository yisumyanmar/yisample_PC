<template>
  <div class='welcomeShopSn'>
    <h1>欢迎使用S-ho-psN</h1>
  </div>
</template>
<script>
export default {
  data () {
    return {
    }
  }
}
</script>
<style lang="scss" scoped>
.welcomeShopSn {
  display: flex;
  flex: 1;
  height: 100%;
  justify-content: center;
  align-items: center;
  // background: linear-gradient(to left,
  //  rgba(0,0,0, 0.4) 0%,
  // black 0%,
  //  transparent 100%,
  // );
  h1 {
    font-size: -webkit-xxx-large;
    color: black;
    // -webkit-text-fill-color: black;   
    // -webkit-text-stroke:2px blue;
  }
}
</style>
